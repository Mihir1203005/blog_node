import React from 'react'

const Home = () => {
  return (
    <div>
      <img src="https://image.adsoftheworld.com/q62gjvwf9qo25087encoojuxbigj" className='blog-image' alt="" />
    </div>
  )
}

export default Home
